<div class="pagination">
    <button class="load-more"><?php _e( 'Load More', 'learndash-course-grid' ) ?></button>
</div>